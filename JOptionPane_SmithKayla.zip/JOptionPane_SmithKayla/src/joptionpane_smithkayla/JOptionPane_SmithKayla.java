package joptionpane_smithkayla;
import javax.swing.JOptionPane;
/**
 *
 * @author smithk9202
 */
public class JOptionPane_SmithKayla
{
    public static void main(String[] args)
    {
        // Starting variables, array for shape choice so more can be added later.
        String name, shape;
        String[] choices = {"Rectangle", "Circle"};
        
        // Input user's name
        name = JOptionPane.showInputDialog("Welcome, what is your name?", "Enter your name");
        
        // Choose a shape
        shape = (String) JOptionPane.showInputDialog(null, "Choose a shape to calculate its area."
            , "Choose Your Shape", JOptionPane.QUESTION_MESSAGE, null,
            choices,
            choices[0]);
        
        // User chooses rectangle
        if (shape == "Rectangle")
        {
            // Variables for rectangle
            double length = 0, width = 0, area = 0;
            boolean valid = true;
            
            JOptionPane.showMessageDialog(null, "Hello " + name + ", your shape is rectangle.");

            do
            {
                // Input length. Try catch is used to prevent invalid input, but right now it only works one time.
                try
                {
                    length = Integer.parseInt(JOptionPane.showInputDialog("Enter your rectangle's length", "Length"));
                }
                catch(Exception e)
                {
                    while (length == 0)
                    {
                        length = Integer.parseInt(JOptionPane.showInputDialog("Invalid length. Try again?", "Length"));
                    }
                }
                
                // Input width
                try
                {
                    width = Integer.parseInt(JOptionPane.showInputDialog("Enter your rectangle's width", "Width"));
                }
                catch(Exception e)
                {
                    while (width == 0)
                    {
                        width = Integer.parseInt(JOptionPane.showInputDialog("Invalid width. Try again?", "Width"));
                    }
                }
                
                // Check if width is greater than length, if so, repeat input to get correct length and width
                if (width > length || width <= 0 || length <= 0)
                {
                    JOptionPane.showMessageDialog(null, "Width is greater than length or an invalid number was entered. Please enter length and width again.");
                    valid = false;
                }
                else
                {
                    valid = true;
                }
                
            } while (valid == false);
            
            // Calculate area and display to user
            area = length * width;
            JOptionPane.showMessageDialog(null, name + ", the area of your rectangle is " + area);
        }
        
        // User chooses circle
        if (shape == "Circle")
        {
            // Variables for circle. Pi is rounded.
            double radius = 0, area = 0;
            boolean valid = true;
            final double PI = 3.1416;
            
            JOptionPane.showMessageDialog(null, "Hello " + name + ", your shape is circle.");

            do
            {
                // Input radius. Try catch is used to prevent invalid input, but right now it only works one time.
                try
                {
                    radius = Integer.parseInt(JOptionPane.showInputDialog("Enter your circle's radius", "Radius"));
                }
                catch(Exception e)
                {
                    while (radius == 0)
                    {
                        radius = Integer.parseInt(JOptionPane.showInputDialog("Invalid radius. Try again?", "Radius"));
                    }
                }
                
                // Validate radius
                if (radius <= 0)
                {
                    JOptionPane.showMessageDialog(null, "An invalid number was entered. Please enter radius again.");
                    valid = false;
                }
                else
                {
                    valid = true;
                }
                
            } while (valid == false);
            
            // Calculate area and display to user
            area = (radius * radius) * PI;
            JOptionPane.showMessageDialog(null, name + ", the area of your circle is " + area);
        }
    }
    
}
