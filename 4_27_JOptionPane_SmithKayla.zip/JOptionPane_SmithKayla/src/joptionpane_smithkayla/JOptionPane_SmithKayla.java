package joptionpane_smithkayla;
import javax.swing.JOptionPane;
/**
 *
 * @author smithk9202
 */
public class JOptionPane_SmithKayla
{
    public static void main(String[] args)
    {
        
        // Input user's name
        String name = Menu.GetUserName();
        
        // Choose a shape
        String shape = Menu.GetUserShape();
        
        switch (shape)
        {
            case "Rectangle":
                // Variables for rectangle
                // IMPORTANT NOTE: Other shapes may use these variables.
                double length = 0, width = 0, area;
                boolean valid;

                do
                {
                    // Input length
                    length = Rectangle.GetRectangleLength();

                    // Input width
                    width = Rectangle.GetRectangleWidth();

                    // Check if width is greater than length
                    valid = Rectangle.CheckRectangleSides(length, width);
                } while (valid == false);

                // Calculate area
                area = Rectangle.GetRectangleArea(length, width);
                
                // Display to user
                JOptionPane.showMessageDialog(null, name + ", the area of your rectangle is " + area);
                break;
            
            case "Circle":
                // Variable for radius. Area is declared in the rectangle shape.
                double radius;

                radius = Circle.GetCircleRadius();
                
                // Calculates area
                area = Circle.GetCircleArea(radius);
                
                // Display to user
                JOptionPane.showMessageDialog(null, name + ", the area of your circle is " + area);
                break;
        }
    }
    
}
