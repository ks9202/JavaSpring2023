/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author smithk9202
 */
public class Rectangle
{
    // This class handles input and calculations for the rectangle shape
    
    public static double GetRectangleLength()
    {
        // Returns rectangle length
        double length = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                length = Double.parseDouble(JOptionPane.showInputDialog("Enter your rectangle's length", "Length"));
                // length = Double.parseDouble(JOptionPane.INPUT_VALUE_PROPERTY.

                // Invalid input (numeric)
                if (length <= 0)
                {
                    while (length <= 0)
                    {
                        length = Double.parseDouble(JOptionPane.showInputDialog("Invalid length. Try again?", "Length"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid length. Please try again.");
            }
        }
        return length;
    }
    
    public static double GetRectangleWidth()
    {
        // Returns rectangle width
        double width = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                width = Double.parseDouble(JOptionPane.showInputDialog("Enter your rectangle's width", "Width"));

                // Invalid input (numeric)
                if (width <= 0)
                {
                    while (width <= 0)
                    {
                        width = Double.parseDouble(JOptionPane.showInputDialog("Invalid width. Try again?", "Width"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid width. Please try again.");
            }
        }
        return width;
    }
    
    public static boolean CheckRectangleSides(double length, double width)
    {
        boolean valid;
        if (width > length || width <= 0 || length <= 0)
        {
            JOptionPane.showMessageDialog(null, "Width is greater than length. Please enter length and width again.");
            valid = false;
        }
        else
        {
            valid = true;
        }
        return valid;
    }
    
    public static double GetRectangleArea(double length, double width)
    {
        // Returns rectangle area
        double area = length * width;
        return area;
    }
}
