# -*- coding: utf-8 -*-
"""
    Functions for M5Pro
    11/15/2023
    CSC121 M5Pro
    Kayla Smith
"""
import csv

def printMenu():
    # Formatted menu
    print("----------------MENU-------------------------")
    print("1) Print existing totals")
    print("2) Add new transactions to file")
    print("3) Exit")
    print("---------------------------------------------")
    
def readFile():
    """
    Splits the sales.csv file into headers and rows list for data processing.

    Returns
    -------
    header : List
        Contains original headers belonging to sales.csv.
    rows : List
        Contains sales data from sales.csv.

    """
    with open("sales.csv", "r") as file:
        # Assigns file header to header variable, splits into list, removes newline
        header = next(file)
        header = header.split(",")
        header[5] = header[5].rstrip("\n")
        
        # Initialize reader
        reader = csv.reader(file)
        
        # Initialize rows
        rows = []
        
        # Appends each row to list of rows
        for row in reader:
            rows.append(row)
        
        return header, rows

def printFile(totalHeader, totalRows):
    """
    Prints formatted totals to the screen.

    Parameters
    ----------
    totalHeader : List
        List of headers writen to display totals to the user.
    totalRows : List
        List of totals information.

    Returns
    -------
    None.

    """
    
    for head in totalHeader:
        print("%20s" % head, end="")
    print("\n")

    for row in totalRows:
        for val in row:
            print("%20s" % val, end="")
        print("\n")

def createNewTrans(rows):
    """
    Guides the user through creating a new transaction, which
    is appended to the existing list of row data from sales.csv.
    This function does not write it to the file, and the new transaction
    will be lost if not written.

    Parameters
    ----------
    rows : List
        Data from sales.csv.

    Returns
    -------
    rows : List
        Data from sales.csv, with one new custom entry appended.

    """
    
    # Initialize list to hold all values to be put into rows
    temp = []
    
    # Input transaction number
    transNum = input("Enter transaction number: ")
    # Validation
    while not isInt(transNum):
        print("Invalid entry. Must be an integer.")
        transNum = input("Enter transaction number: ")
    int (transNum)
    temp.append(transNum)
        
    # Input sale date
    saleDate = input("Enter sale date (m/d/yyyy): ")
    temp.append(saleDate)
    
    # Input product ID
    prodID = input("Enter product ID: ")
    temp.append(prodID)
    
    # Input customer #
    custNum = input("Enter customer number: ")
    # Validation
    while not isInt(custNum):
        print("Invalid entry. Must be an integer.")
        custNum = input("Enter transaction number: ")
    int(custNum)
    temp.append(custNum)
        
    # Input units sold
    unitSold = input("Enter units sold: ")
    while not isInt(unitSold):
        print("Invalid entry. Must be an integer.")
        unitSold = input("Enter units sold: ")
    int(unitSold)
    temp.append(unitSold)
    
    # Input price per unit
    unitPrice = input("Enter price per unit: ")
    while not isFloat(unitPrice):
        print("Invalid entry. Must be a number.")
        unitPrice = input("Enter price per unit: ")
    float(unitPrice)
    temp.append(unitPrice)
    
    # Add new transaction to list of transactions
    rows.append(temp)

    return rows

def writeNewTrans(header, rows):
    """
    Writes a new transaction to the sales.csv file.

    Parameters
    ----------
    header : List
        Original headers from sales.csv.
    rows : List
        Data originally from sales.csv.

    Returns
    -------
    None.

    """
    with open("sales.csv", "w", newline="") as file:
        
        # Initialize writer
        writer = csv.writer(file)
        
        writer.writerow(header)
        writer.writerows(rows)
        
        print("New transaction successfully added to file.")

def writeToTxt(totalHeader, totalRows):
    """
    Writes totals information to sales.txt.

    Parameters
    ----------
    totalHeader : List
        List of headers to display totals.
    totalRows : List
        List containing totals information.

    Returns
    -------
    None.

    """
    
    with open("sales.txt", "w") as file:
            
        for head in totalHeader:
            file.write("%20s" % head)
        file.write("\n")

        for row in totalRows:
            for val in row:
                file.write("%20s" % val)
            file.write("\n")

def calcTotals(rows):
    """
    Returns a list containing product ID values, the total
    number sold from sales.csv transactions, and the total
    revenue generated by this product ID.

    Parameters
    ----------
    rows : List
        Data from sales.csv.

    Returns
    -------
    totalList : List
        List of totals per product ID.

    """
    
    idList = []
    totalList = []
    unitNum = 0
    unitPrice = 0
    
    for row in rows:
        if rows[rows.index(row)][2] not in idList:
            idList.append(rows[rows.index(row)][2])
    
    for idNum in idList:
        for row in rows:
            if rows[rows.index(row)][2] == idNum:
                unitNum += int(rows[rows.index(row)][4])
                unitPrice = float(rows[rows.index(row)][5])
        totalList.append([idNum, unitNum, unitPrice * unitNum])
        unitNum = 0
    
    return totalList
    
def isFloat(value):
    """
    Tests whether a string is a float

    Parameters
    ----------
    value : String
        String to be tested for being float.

    Returns
    -------
    bool
        Returns True if string can be converted to float, False if not.

    """
    try:
        float(value)
        return True
    except:
        return False
    
def isInt(value):
    """
    Tests whether a string is an int

    Parameters
    ----------
    value : String
        String to be tested for being int.

    Returns
    -------
    bool
        Returns True if string can be converted to int, False if not.

    """
    try:
        int(value)
        return True
    except:
        return False
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    