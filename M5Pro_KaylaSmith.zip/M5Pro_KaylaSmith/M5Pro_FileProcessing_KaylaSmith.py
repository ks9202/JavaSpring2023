# -*- coding: utf-8 -*-
"""
    This program allows the user to read transaction data from a csv file or add
    new transaction data, then display the totals for the data based on
    productIDs. Totals will also be printed to a .txt file.
    11/15/2023
    CSC121 M5Pro
    Kayla Smith
"""

import M5Pro_Func as Func

def main():
    
    totalHeader = ["ProductID", "Total Units Sold", "Total Sales"]
    
    # Prints menu
    Func.printMenu()
    print()
    # Menu option selection
    menuInput = input("Select an option (1, 2, or 3): ")
    # Exits once the exit option is selected
    while menuInput != "3":
        
        # Input validation
        while menuInput != "1" and menuInput != "2" and menuInput != "3":
            print("Input invalid. Try again?")
            menuInput = input("Select an option (1, 2, or 3): ")
        
        # Read file
        header, rows = Func.readFile()
        # Create total sales data
        totalRows = Func.calcTotals(rows)
        
        # Runs if 1 is selected
        if menuInput == "1":
            
            print()
            # Prints file, tabular format
            Func.printFile(totalHeader, totalRows)
            # Prints transaction information to a .txt file
            Func.writeToTxt(totalHeader, totalRows)
        
        # Runs if 2 is selected
        elif menuInput == "2":
            
            print()
            # Make a new transaction
            rows = Func.createNewTrans(rows)
            # Writes new transaction to file
            Func.writeNewTrans(header, rows)
        
        # Print menu again, 1 or 2 selected
        print()
        Func.printMenu()
        print()
        menuInput = input("Select an option (1, 2, or 3): ")
        
    # Exit message, 3 selected
    print()
    print("Exiting program...")
    

if __name__ =="__main__":
    main()