/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author smithk9202
 */
public class Circle
{
    // This class handles input and calculations for the circle shape
    
    public static double GetCircleRadius()
    {
        // Returns rectangle length
        double radius = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                radius = Double.parseDouble(JOptionPane.showInputDialog("Enter your circle's radius", "Radius"));

                // Invalid input (numeric)
                if (radius <= 0)
                {
                    while (radius <= 0)
                    {
                        radius = Double.parseDouble(JOptionPane.showInputDialog("Invalid radius. Try again?", "Radius"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid radius. Please try again.");
            }
        }
        return radius;
    }
    
    public static double GetCircleArea(double radius)
    {
        final double PI = 3.1416;
        double area = (radius * radius) * PI;
        return area;
    }
}
