/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class Triangle
{
    // This class handles input and calculations for the triangle shape.
    
    public static double GetTriangleBase()
    {
        // Returns triangle base
        double base = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                base = Double.parseDouble(JOptionPane.showInputDialog("Enter your triangle's base length", "Base"));

                // Invalid input (numeric)
                if (base <= 0)
                {
                    while (base <= 0)
                    {
                        base = Double.parseDouble(JOptionPane.showInputDialog("Invalid base length. Try again?", "Base"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid base length. Please try again.");
            }
        }
        return base;
    }
    
    public static double GetTriangleHeight()
    {
        // Returns triangle height
        double height = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                height = Double.parseDouble(JOptionPane.showInputDialog("Enter your triangle's height", "Height"));

                // Invalid input (numeric)
                if (height <= 0)
                {
                    while (height <= 0)
                    {
                        height = Double.parseDouble(JOptionPane.showInputDialog("Invalid height. Try again?", "Height"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid height. Please try again.");
            }
        }
        return height;
    }
    
    public static boolean CheckTriangle(double base, double height)
    {
        // Checks if height is greater than base
        boolean valid;
        if (height > base || height <= 0 || base <= 0)
        {
            JOptionPane.showMessageDialog(null, "Height is greater than base length. Please enter base and height again.");
            valid = false;
        }
        else
        {
            valid = true;
        }
        return valid;
    }
    
    public static double GetTriangleArea(double base, double height)
    {
        // Returns triangle area
        double area = (base * height) / 2;
        return area;
    }
}
