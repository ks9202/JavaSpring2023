/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class Cube 
{    
    // This class handles input and calculations for the cube shape.
    
    public static double GetCubeSide()
    {
        // Returns cube side length
        double side = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                side = Double.parseDouble(JOptionPane.showInputDialog("Enter your cube's side length", "Side Length"));

                // Invalid input (numeric)
                if (side <= 0)
                {
                    while (side <= 0)
                    {
                        side = Double.parseDouble(JOptionPane.showInputDialog("Invalid side length. Try again?", "Side Length"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid side length. Please try again.");
            }
        }
        return side;
    }
    
    public static double GetCubeVolume(double side)
    {
        double volume = side * side * side;
        return volume;
    }
}
