/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author smithk9202
 */
public class Menu
{
    // This class controls the menu.
    
    public static String GetUserName()
    {
        // Returns user's input of name
        String name = JOptionPane.showInputDialog("Welcome, what is your name?", "Enter your name");
        return name;
    }
    
    public static String GetUserShape()
    {
        // Returns user's choice of shape
        String[] shapes = {"Rectangle", "Circle", "Square", "Parallelogram", "Triangle", "Trapezoid", "Cube"};
        
        String userShape = (String) JOptionPane.showInputDialog(null, "Choose a shape to calculate its area or volume."
            , "Choose Your Shape", JOptionPane.QUESTION_MESSAGE, null,
            shapes,
            shapes[0]);
        
        return userShape;
    }
}
