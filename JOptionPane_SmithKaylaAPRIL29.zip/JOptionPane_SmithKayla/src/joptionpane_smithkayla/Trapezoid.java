/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class Trapezoid {
    
    // This class handles input and calculations for the trapezoid shape.
    
    public static double GetTrapezoidBase1()
    {
        // Returns trapezoid's shorter base
        double base1 = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                base1 = Double.parseDouble(JOptionPane.showInputDialog("Enter your trapezoid's shorter base length", "Short base"));

                // Invalid input (numeric)
                if (base1 <= 0)
                {
                    while (base1 <= 0)
                    {
                        base1 = Double.parseDouble(JOptionPane.showInputDialog("Invalid length. Try again?", "Short base"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid length. Please try again.");
            }
        }
        return base1;
    }
    
    public static double GetTrapezoidBase2()
    {
        // Returns trapezoid's longer base
        double base2 = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                base2 = Double.parseDouble(JOptionPane.showInputDialog("Enter your trapezoid's longer base length", "Long base"));

                // Invalid input (numeric)
                if (base2 <= 0)
                {
                    while (base2 <= 0)
                    {
                        base2 = Double.parseDouble(JOptionPane.showInputDialog("Invalid length. Try again?", "Long base"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid length. Please try again.");
            }
        }
        return base2;
    }
    
    public static double GetTrapezoidHeight()
    {
        // Returns trapezoid height
        double height = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                height = Double.parseDouble(JOptionPane.showInputDialog("Enter your trapezoid's height", "Height"));

                // Invalid input (numeric)
                if (height <= 0)
                {
                    while (height <= 0)
                    {
                        height = Double.parseDouble(JOptionPane.showInputDialog("Invalid height. Try again?", "Height"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid height. Please try again.");
            }
        }
        return height;
    }
    
    public static boolean CheckTrapezoid(double base1, double base2, double height)
    {
        // Checks if height is greater than length
        boolean valid;
        if (height > base1 || height > base2)
        {
            JOptionPane.showMessageDialog(null, "Height is greater than either base length. Please enter values again.");
            valid = false;
        }
        else if (base1 > base2)
        {
            JOptionPane.showMessageDialog(null, "Short base is greater than long base. Please enter values again.");
            valid = false;
        }
        else
        {
            valid = true;
        }
        return valid;
    }
    
    public static double GetTrapezoidArea(double base1, double base2, double height)
    {
        // Returns trapezoid area
        double area = (.5 * height) * (base1 + base2);
        return area;
    }
}
