package joptionpane_smithkayla;
import javax.swing.JOptionPane;
/**
 *
 * @author smithk9202
 */
public class JOptionPane_SmithKayla
{
    public static void main(String[] args)
    {
        
        // Input user's name
        String name = Menu.GetUserName();
        
        // Choose a shape
        String shape = Menu.GetUserShape();
        
        switch (shape)
        {
            case "Rectangle":
                // Variables for rectangle
                // IMPORTANT NOTE: Other shapes may use these variables.
                double length = 0, width = 0, area;
                boolean valid;

                do
                {
                    // Input length
                    length = Rectangle.GetRectangleLength();

                    // Input width
                    width = Rectangle.GetRectangleWidth();

                    // Check if width is greater than length
                    valid = Rectangle.CheckRectangle(length, width);
                } while (valid == false);

                // Calculate area
                area = Rectangle.GetRectangleArea(length, width);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your rectangle is " + area);
                break;
            
            case "Circle":
                // Variable for radius. Area is declared in the rectangle shape.
                double radius;

                // Input radius
                radius = Circle.GetCircleRadius();
                
                // Calculates area
                area = Circle.GetCircleArea(radius);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your circle is " + area);
                break;
                
            case "Square":
                // Variable for side length. Area is declared in the rectangle shape.
                double side;
                
                // Input side length
                side = Square.GetSquareSide();
                
                // Calculate area
                area = Square.GetSquareArea(side);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your square is " + area);
                break;
                
            case "Parallelogram":
                // Variable for height. Area and length are declared in the rectangle shape.
                double height;
                
                do
                {
                    // Input length
                    length = Parallelogram.GetParallelogramLength();

                    // Input height
                    height = Parallelogram.GetParallelogramHeight();

                    // Check if height is greater than length
                    valid = Parallelogram.CheckParallelogram(length, height);
                } while (valid == false);
                
                // Calculate area
                area = Parallelogram.GetParallelogramArea(length, height);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your parallelogram is " + area);
                break;
                
            case "Triangle":
                    // Variable for base. Area and height are declared in the other shapes.
                double base;
                
                do
                {
                    // Input length
                    base = Triangle.GetTriangleBase();

                    // Input height
                    height = Triangle.GetTriangleHeight();

                    // Check if height is greater than length
                    valid = Triangle.CheckTriangle(base, height);
                } while (valid == false);
                
                // Calculate area
                area = Triangle.GetTriangleArea(base, height);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your triangle is " + area);
                break;
                
            case "Trapezoid":
                    // Variable for base1 and base2. Area and height are declared in the other shapes.
                    // base1 is the shorter base, and base2 is the longer base.
                double base1, base2;
                
                do
                {
                    // Input base1
                    base1 = Trapezoid.GetTrapezoidBase1();

                    // Input base2
                    base2 = Trapezoid.GetTrapezoidBase2();

                    // Input height
                    height = Trapezoid.GetTrapezoidHeight();
                    
                    // Check trapezoid
                    valid = Trapezoid.CheckTrapezoid(base1, base2, height);
                } while (valid == false);
                
                // Calculate area
                area = Trapezoid.GetTrapezoidArea(base1, base2, height);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the area of your trapezoid is " + area);
                break;
                
            case "Cube":
                // Variable for volume. Side variable declared in another shape.
                double volume;
                
                // Input side length
                side = Cube.GetCubeSide();
                
                // Calculate volume
                volume = Cube.GetCubeVolume(side);
                
                // Output
                JOptionPane.showMessageDialog(null, name + ", the volume of your square is " + volume);
                break;
        }
    }
    
}
