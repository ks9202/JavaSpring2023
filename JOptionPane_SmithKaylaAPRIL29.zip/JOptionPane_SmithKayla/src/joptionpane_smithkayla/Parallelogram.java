/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpane_smithkayla;

import javax.swing.JOptionPane;

/**
 *
 * @author kkimh
 */
public class Parallelogram
{
    // This class handles input and calculations for the parallelogram shape.
    
    public static double GetParallelogramLength()
    {
        // Returns parallelogram length
        double length = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                length = Double.parseDouble(JOptionPane.showInputDialog("Enter your parallelogram's length", "Length"));

                // Invalid input (numeric)
                if (length <= 0)
                {
                    while (length <= 0)
                    {
                        length = Double.parseDouble(JOptionPane.showInputDialog("Invalid length. Try again?", "Length"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid length. Please try again.");
            }
        }
        return length;
    }
    
    public static double GetParallelogramHeight()
    {
        // Returns parallelogram height
        double height = 0;
        boolean valid = false;
        
        while (valid == false)
        {
            try
            {
                height = Double.parseDouble(JOptionPane.showInputDialog("Enter your parallelogram's height", "Height"));

                // Invalid input (numeric)
                if (height <= 0)
                {
                    while (height <= 0)
                    {
                        height = Double.parseDouble(JOptionPane.showInputDialog("Invalid height. Try again?", "Height"));
                    }
                }
                else
                {
                    valid = true;
                }
            }
            catch(Exception e)
            {
                // Invalid input (non numeric or null)
                JOptionPane.showMessageDialog(null, "Invalid height. Please try again.");
            }
        }
        return height;
    }
    
    public static boolean CheckParallelogram(double length, double height)
    {
        // Checks if height is greater than length
        boolean valid;
        if (height > length || height <= 0 || length <= 0)
        {
            JOptionPane.showMessageDialog(null, "Height is greater than length. Please enter length and height again.");
            valid = false;
        }
        else
        {
            valid = true;
        }
        return valid;
    }
    
    public static double GetParallelogramArea(double length, double height)
    {
        // Returns parallelogram area
        double area = length * height;
        return area;
    }
}
